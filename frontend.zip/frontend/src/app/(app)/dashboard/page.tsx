"use client";

import { DashboardHeader } from "@/features/dashboard/DashboardHeader";
import { StatsRow } from "@/features/dashboard/StatsRow";
import { ProjectsGrid } from "@/features/dashboard/ProjectsGrid";
import { RecentActivity } from "@/features/dashboard/RecentActivity";

export default function DashboardPage() {
  return (
    <div className="flex flex-col h-full w-full">
      <div className="flex-1 overflow-y-auto">
        <div className="p-8">
        <DashboardHeader />
        <StatsRow />
        
        <div className="mb-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Projects</h2>
          <ProjectsGrid />
        </div>

        <div className="mb-6">
          <RecentActivity maxItems={5} />
        </div>
        </div>
      </div>
    </div>
  );
}
